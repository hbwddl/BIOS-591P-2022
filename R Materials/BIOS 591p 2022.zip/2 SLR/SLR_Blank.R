### SLR R Exercise

# Create Data

# Initial Descriptive Statistics

# Calculate correlation, CI

# Fit SLR model

# Summarize results

# ANOVA table

# confidence intervals for estimated coefficients

# Predict weight at 11 days

# Plot data

# Plot predicted values

# Plot model predictions

# Plot confidence interval lines

# Plot prediction interval lines

# Some ways to clean up the plot
