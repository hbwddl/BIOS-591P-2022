print("hello")

normdata <- rnorm(1000)
hist(normdata)