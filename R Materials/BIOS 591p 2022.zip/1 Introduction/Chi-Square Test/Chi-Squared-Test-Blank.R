### Chi-squared test in R

### Chi-squared test with contingency table
# Create contingency table

# Check assumption (>5 expected in at least 80% of the cells)


### Chi-squared test with dataset
## Set working directory

# Read in the dataset

# Conduct chi-squared test

# Check assumption (>5 expected in at least 80% of the cells)

