### Logistic regression in R

## Necessary packages

## Set working directory and read in the data

## Deal with categorical variables

## Fit model

## Change reference level

## Likelihood ratio test

## Type III test

## C Statistic

## Odds Ratios