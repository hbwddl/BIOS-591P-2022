### Multiple Linear Regression
### Initial Report

## Install sas7bdat package

## Set working directory

## Read in the data

## Descriptive Statistics
## Continuous: Mean, SD, Quantiles

## Correlation

## Fit MLR and see results

## Check normality of residuals
